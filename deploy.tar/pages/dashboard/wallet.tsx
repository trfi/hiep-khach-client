import { DashboardLayout } from "@/components/layouts"
import { NextPageWithLayout } from "@/models"

const Wallet: NextPageWithLayout = () => {
  return (
    <div>Wallet</div>
  )
}

Wallet.Layout = DashboardLayout

export default Wallet